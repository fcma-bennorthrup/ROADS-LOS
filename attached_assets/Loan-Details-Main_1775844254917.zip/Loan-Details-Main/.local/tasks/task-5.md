---
title: Add Generate Rate Lock Letter button when rate is locked
---
---
  title: Add Generate Rate Lock Letter button when rate is locked
  ---
  # Add "Generate Rate Lock Letter" Button

  ## What
  When the rate is locked and the "Edit Rate Lock" button is showing, display a secondary "Generate Rate Lock Letter" button next to it, styled like the existing "Edit" button (outline style).

  ## Done looks like
  - When isRateLocked is true, a "Generate Rate Lock Letter" button appears next to "Edit Rate Lock"
  - Button uses the same outline style as the "Edit" button: outline variant, border #929A9B, white bg, dark text (#273333), hover bg #e5eff4, Source Sans Pro semibold 14px
  - Button is non-functional (no click handler needed beyond placeholder)

  ## Implementation
  - In ProductPricingSection.tsx, add the button in the justify-end div near the "Lock Rate" / "Edit Rate Lock" button
  - Only render when isRateLocked === true

  ## Relevant files
  - client/src/pages/sections/ProductPricingSection.tsx