# Rate Lock Modal Dialog

## What & Why
Add a dialog modal that opens when the user clicks "Lock Rate", allowing them to confirm the rate lock with a pre-populated date and fee information. After locking, the UI updates to show a lock icon on the Final Rate and changes the button to "Edit Rate Lock".

## Done looks like
- Clicking "Lock Rate" opens a modal dialog
- Modal matches Figma design: header with title "Rate Lock", subtitle, close X button, date field, fee info, footer with Cancel and Lock Rate buttons
- Date field is pre-populated with current date + 45 days (MM/DD/YYYY format), disabled/non-editable, with a calendar icon
- Clicking X or Cancel closes the modal with no changes
- Clicking "Lock Rate" in the modal closes it, adds a lock icon next to the Final Rate value in the Rate Breakdown card
- After locking, the "Lock Rate" button text changes to "Edit Rate Lock"
- If "Edit Rate Lock" is clicked, the same modal opens again

## Modal Design (from Figma node 11:1438)

### Header
- Title: "Rate Lock" (Source Sans Pro SemiBold 24px, #273333)
- Subtitle: "Please advise borrower of rate lock fees." (Source Sans Pro Regular 16px, #273333)
- Close X button: 32px round button, top-right
- Bottom border: #dee1e1

### Body
- Date label: "Date" (Source Sans Pro SemiBold 16px, #273333)
- Date input: 312px wide, border #929a9b, Source Sans Pro SemiBold 16px, calendar icon on right, DISABLED
- Date value: 45 days from current date, format MM/DD/YYYY
- Fee information (Source Sans Pro Regular 14px, black):
  - "Fee information:"
  - Bullet: "The rate lock period can be extended for a fee (0.01% of the total loan amount per day)."
  - Bullet: "If rate lock is withdrawn and re-locked, a fee of 1.25% of the total loan amount will apply."

### Footer
- Top border: #dee1e1
- Left text: "Initial Rate Lock Period is 45 days." (Source Sans Pro Regular 14px, #273333)
- Cancel button: text-only button (Source Sans Pro SemiBold 16px, #273333), px-4 py-2
- "Lock Rate" button: green #5e9732 bg, white text, Source Sans Pro SemiBold 16px, px-4 py-2, rounded 4px

## Implementation
- Use shadcn Dialog component
- Add `isRateLocked` state to ProductPricingSection
- Add `isLockModalOpen` state for dialog visibility
- Use lucide-react `Lock` and `Calendar` icons
- Lock icon appears after Final Rate value when locked

## Relevant files
- `client/src/pages/sections/ProductPricingSection.tsx`
