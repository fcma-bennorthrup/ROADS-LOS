---
title: Add Origination tab with side navigation and Product & Pricing content
---
# Add Origination Tab with Side Navigation and Product & Pricing Content

## What & Why
Add the "Origination" tab view to the loan management application based on the Figma design. When the Origination tab is active, the page layout changes from the current Summary view to a side navigation + content area layout. The first content section to implement is "Product & Pricing."

## Done looks like
- The tab navigation in the header defaults to "Origination" as the active tab
- When Origination is active, a 240px left side navigation appears below the header with menu items: Borrower Information, Loan Details, Collateral, Product & Pricing, and Fees
- "Product & Pricing" is the active/selected item in the side navigation (shown in bold)
- The main content area (to the right of the side nav) displays the Product & Pricing section with:
  - A "Product & Pricing" section title
  - A Rate Breakdown row showing: Rate Breakdown label, Base Rate (6.500%), + Total Adjustments (0.625%), - Total Discounts (0.250%), = Final Rate (6.875%) in a bordered rounded card
  - A "Primary" action button below the rate breakdown
  - A form row with four fields: Product Type (dropdown, "Fixed"), Product (dropdown, "4370 - 10yr Fixed"), Term (text input), Rate (text input)
  - A "Save" button below the form fields
  - A Rate Adjustments panel to the right of the form fields listing: FICO Score (0.025%), Loan Size (0.000%), Property Type (0.625%) with a help icon
- The bottom toolbar remains unchanged
- The existing Summary tab content (Borrower Contact Information and Summary & Ratios) remains accessible when the Summary tab is selected

## Out of scope
- Actual form functionality or data persistence (inputs are display-only for now)
- Other side nav items' content pages (Borrower Information, Loan Details, Collateral, Fees)
- Backend API integration for product/pricing data
- Other tab content (Decisioning, Closing & Booking, Documents, History)

## Tasks
1. **Make tabs stateful** — Convert the header's tab navigation from static `defaultValue="summary"` to a controlled state so the active tab can switch between Summary and Origination, defaulting to Origination.

2. **Create side navigation component** — Build a new OriginationSideNav component (240px wide, white background, right border) with the five navigation items from the Figma design, with "Product & Pricing" as the active/bold item.

3. **Build Product & Pricing content section** — Create a new ProductPricingSection component containing the rate breakdown card, form fields (Product Type, Product, Term, Rate dropdowns/inputs), action buttons (Primary, Save), and the Rate Adjustments panel.

4. **Create Origination page layout** — Build a new OriginationPage (or modify the page structure) that composes the side navigation and Product & Pricing content in a horizontal layout below the header, with the toolbar at the bottom.

5. **Wire tab switching** — Connect the tab state so selecting "Summary" shows the existing Summary content and selecting "Origination" shows the new side nav + content layout.

## Relevant files
- `client/src/pages/SummaryPage.tsx`
- `client/src/pages/sections/LoanHeaderSection.tsx`
- `client/src/pages/sections/NavigationToolbarSection.tsx`
- `client/src/pages/sections/LoanDetailsSection.tsx`
- `client/src/pages/sections/BorrowerSummarySection.tsx`
- `client/src/App.tsx`