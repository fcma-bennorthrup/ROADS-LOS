# Add Product & Pricing Edit Logic with Rate Lookup

## What & Why
Add interactive edit mode to the Product & Pricing form so users can change Product Type, Product, and Term, with the Base Rate automatically calculated from a product data table. Currently all fields are static/display-only.

## Done looks like
- Clicking "Edit" enables the form fields, and the button changes to a primary "Save Changes" button (green #5e9732 bg, white text, no icon)
- Clicking "Save Changes" locks the fields back to read-only and reverts the button to the secondary "Edit" style
- Product Type dropdown shows only "Fixed" and "ARM" (remove "Variable")
- Selecting a Product Type filters the Product dropdown to show only matching products
- Selecting a Product auto-fills the Term field with the product's allowed term (read-only)
- Base Rate is auto-looked up from the data table based on Product Type + Product + Term and displayed (read-only)
- The Rate Breakdown card's Base Rate value updates to reflect the looked-up rate
- Default state on load: Product Type = Fixed, Product = 4370 - 10 year fixed, Term = 120, Base Rate = 6.125%

## Product Data Table

### ARM Products
| Product | Term (Months) | Base Rate |
|---|---|---|
| 4251 - 1/1 ARM 2/6 caps | 12 | 6.250 |
| 4243 - 3/1 ARM 2/6 caps | 36 | 6.370 |
| 4245 - 5/1 ARM 2/6 caps | 60 | 6.500 |
| 4247 - 7/1 ARM 2/6 caps | 84 | 6.500 |
| 4240 - 10/1 ARM 9/9caps | 120 | 6.500 |
| 4242 - 15/1 ARM 9/9 caps | 180 | 6.750 |

### Fixed Products
| Product | Term (Months) | Base Rate |
|---|---|---|
| 4370 - 10 year fixed | 120 | 6.125 |
| 4371 - 15 year fixed | 180 | 6.375 |
| 4372 - 20 year fixed | 240 | 6.625 |
| 4373 - 25 year fixed | 300 | 6.750 |
| 4374 - 30 year fixed | 360 | 6.750 |

## Implementation Details

### State management
- Add `isEditing` boolean state (default false)
- Add `productType` state (default "fixed")
- Add `selectedProduct` state (default "4370")
- Derive `term` and `baseRate` from the selected product in the data table
- Update rateBreakdownData.baseRate dynamically

### Edit/Save toggle
- When `isEditing` is false: fields are disabled, button shows "Edit" (outline, pencil icon, existing style)
- When `isEditing` is true: Product Type and Product dropdowns are enabled, button shows "Save Changes" (primary, green bg like Lock Rate but green #5e9732)
- Term and Base Rate fields are always read-only (auto-derived from product selection)

### Cascading selection
- When Product Type changes: reset Product to the first product of that type, which updates Term and Base Rate
- When Product changes: update Term and Base Rate from the data table
- Product dropdown options filtered by selected Product Type

## Relevant files
- `client/src/pages/sections/ProductPricingSection.tsx` (main file to modify)

## Out of scope
- Backend persistence
- Rate Adjustments calculation changes
- Final Rate recalculation (Total Adjustments and Total Discounts remain hardcoded)
