---
title: Side navigation visual tweaks
---
# Side Navigation Visual Tweaks

## What & Why
Two small visual fixes to the Origination side navigation to match the desired design.

## Done looks like
- The active side nav item ("Product & Pricing") no longer has a grey background highlight — it only appears bold
- The side navigation's right border extends all the way down to the top of the footer toolbar, not just the height of its content

## Out of scope
- Any other side nav or layout changes

## Tasks
1. **Remove active item background** — Remove the `bg-[#f3f4f4]` class from the active state in OriginationSideNav so the active item is bold text only with no background color.
2. **Extend side nav border to footer** — Ensure the side nav container fills the full height of the content area between the header and toolbar so its right border line runs continuously down to the toolbar.

## Relevant files
- `client/src/pages/sections/OriginationSideNav.tsx`
- `client/src/pages/SummaryPage.tsx`