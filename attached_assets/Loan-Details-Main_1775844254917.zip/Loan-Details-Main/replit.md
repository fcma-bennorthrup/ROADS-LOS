# Overview

This is a loan management application that displays loan summary information, borrower details, and loan processing stages. It's built as a full-stack TypeScript application with a React frontend and Express backend. The current implementation is primarily a frontend UI with two main views:

1. **Summary tab** — Borrower contact information cards and Summary & Ratios section
2. **Origination tab** (default active) — Side navigation (240px) with Product & Pricing content including rate breakdown, product/rate form fields, and rate adjustments panel

The data is currently hardcoded in the frontend components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend

- **Framework**: React 18 with TypeScript, bundled by Vite
- **Routing**: Wouter (lightweight client-side router)
- **State/Data Fetching**: TanStack React Query for server state management
- **Styling**: Tailwind CSS with CSS custom properties for a design-system-driven approach (Source Sans Pro typography, custom color tokens)
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives — full library installed including dialog, tabs, badges, breadcrumbs, cards, avatars, tooltips, etc.
- **Component Location**: `client/src/components/ui/` for reusable UI primitives, `client/src/pages/` for page components, `client/src/pages/sections/` for page section components
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`, `@assets/` maps to `attached_assets/`

## Backend

- **Framework**: Express.js running on Node with TypeScript (tsx for dev, esbuild for production)
- **API Pattern**: All API routes should be prefixed with `/api`
- **Storage**: Currently uses an in-memory storage implementation (`MemStorage` class) with an `IStorage` interface that can be swapped for a database-backed implementation
- **Dev Server**: Vite dev server is integrated as Express middleware in development; static files served in production from `dist/public`

## Shared Layer

- **Location**: `shared/schema.ts`
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Validation**: drizzle-zod for generating Zod schemas from Drizzle table definitions
- **Current Schema**: A `users` table with `id` (UUID, auto-generated), `username` (unique text), and `password` (text)

## Database

- **ORM**: Drizzle ORM configured for PostgreSQL
- **Driver**: `@neondatabase/serverless` (Neon serverless Postgres)
- **Connection**: Via `DATABASE_URL` environment variable
- **Migrations**: Output to `./migrations` directory, managed with `drizzle-kit push` command
- **Session Store**: `connect-pg-simple` is included as a dependency (for Express session storage in Postgres)

## Key Design Decisions

1. **In-memory storage as default**: The `IStorage` interface pattern allows easy swapping between `MemStorage` (for development/testing) and a future `DatabaseStorage` implementation using Drizzle
2. **Monorepo-style structure**: Client, server, and shared code live in the same repository with shared TypeScript types
3. **Static data**: The loan summary page currently uses hardcoded data arrays in the component files rather than fetching from APIs — this is likely placeholder data to be replaced with API calls
4. **Design system**: Heavy use of CSS custom properties for typography and colors, suggesting the UI was designed in Figma and converted to code

# External Dependencies

- **Database**: PostgreSQL via Neon serverless (`@neondatabase/serverless`) — requires `DATABASE_URL` environment variable
- **Fonts**: Google Fonts (Source Sans Pro, DM Sans, Fira Code, Geist Mono, Architects Daughter) loaded via CDN
- **Figma Assets**: Static assets referenced from `/figmaAssets/` directory (e.g., icons for loan stages)
- **No authentication system**: Currently implemented — the users table exists in the schema but no auth routes or middleware are set up
- **No external API integrations**: The app is self-contained with no third-party API calls