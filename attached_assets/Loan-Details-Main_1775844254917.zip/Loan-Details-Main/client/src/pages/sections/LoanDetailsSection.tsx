import { CopyIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const borrowers = [
  {
    name: "Richard Jamerson",
    isPrimary: true,
    email: "richardtjamerson@gmail.com",
    phone: "(123) 456-7890",
  },
  {
    name: "Jamelle Jamerson",
    isPrimary: false,
    email: "jamellepjamerson@gmail.com",
    phone: "(123) 098-7654",
  },
  {
    name: "Priya Sharma",
    isPrimary: false,
    email: "priya.sharma@example.com",
    phone: "(415) 555-0182",
  },
];

export const LoanDetailsSection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full items-center gap-4 relative pt-8">
      <div className="flex items-center py-0 relative w-full" style={{ paddingLeft: 48, paddingRight: 48 }}>
        <h2 className="font-headline-200 font-[number:var(--headline-200-font-weight)] text-[#273333] text-[length:var(--headline-200-font-size)] tracking-[var(--headline-200-letter-spacing)] leading-[var(--headline-200-line-height)] [font-style:var(--headline-200-font-style)]">
          Borrower Contact Information
        </h2>
      </div>

      <div className="flex items-center gap-6 py-0 relative w-full" style={{ paddingLeft: 48, paddingRight: 48 }}>
        {borrowers.map((borrower, index) => (
          <Card
            key={index}
            className="flex-1 bg-white rounded-lg border-[#dee1e1]"
          >
            <CardContent className="flex flex-col items-start gap-4 p-4">
              <div className="flex items-center justify-between w-full">
                <h3 className="font-headline-300 font-[number:var(--headline-300-font-weight)] text-[#273333] text-[length:var(--headline-300-font-size)] tracking-[var(--headline-300-letter-spacing)] leading-[var(--headline-300-line-height)] [font-style:var(--headline-300-font-style)]">
                  {borrower.name}
                </h3>
                {borrower.isPrimary && (
                  <Badge className="bg-[#dcf2ff] text-[#2079c3] hover:bg-[#dcf2ff] font-body-200-strong font-[number:var(--body-200-strong-font-weight)] text-[length:var(--body-200-strong-font-size)] tracking-[var(--body-200-strong-letter-spacing)] leading-[var(--body-200-strong-line-height)] [font-style:var(--body-200-strong-font-style)]">
                    Primary Borrower
                  </Badge>
                )}
              </div>

              <div className="flex flex-col items-start gap-2 w-full">
                <div className="flex items-center justify-between w-full">
                  <div className="flex flex-col items-start gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-ui-specific-label-strong font-[number:var(--ui-specific-label-strong-font-weight)] text-[#273333] text-[length:var(--ui-specific-label-strong-font-size)] tracking-[var(--ui-specific-label-strong-letter-spacing)] leading-[var(--ui-specific-label-strong-line-height)] [font-style:var(--ui-specific-label-strong-font-style)]">
                        Email
                      </span>
                      <CopyIcon className="w-3 h-3 cursor-pointer" />
                    </div>
                    <a
                      href={`mailto:${borrower.email}`}
                      className="underline font-body-100-16 font-[number:var(--body-100-16-font-weight)] text-[#005b94] text-[length:var(--body-100-16-font-size)] tracking-[var(--body-100-16-letter-spacing)] leading-[var(--body-100-16-line-height)] [font-style:var(--body-100-16-font-style)]"
                    >
                      {borrower.email}
                    </a>
                  </div>

                  <div className="flex flex-col w-[104px] items-start gap-2">
                    <span className="font-ui-specific-label-strong font-[number:var(--ui-specific-label-strong-font-weight)] text-[#273333] text-[length:var(--ui-specific-label-strong-font-size)] text-center tracking-[var(--ui-specific-label-strong-letter-spacing)] leading-[var(--ui-specific-label-strong-line-height)] [font-style:var(--ui-specific-label-strong-font-style)]">
                      Phone Number
                    </span>
                    <span className="font-body-100-16 font-[number:var(--body-100-16-font-weight)] text-[#273333] text-[length:var(--body-100-16-font-size)] tracking-[var(--body-100-16-letter-spacing)] leading-[var(--body-100-16-line-height)] [font-style:var(--body-100-16-font-style)]">
                      {borrower.phone}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
