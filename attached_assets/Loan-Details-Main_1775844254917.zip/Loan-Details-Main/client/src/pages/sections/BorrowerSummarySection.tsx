import { Card, CardContent } from "@/components/ui/card";

const summaryData = [
  {
    items: [
      { label: "PITI", value: "36.00%" },
      { label: "DTI", value: "17.00%" },
      { label: "L/CV", value: "80.00%" },
      { label: "PWE CB Score", value: "756" },
    ],
  },
  {
    items: [
      { label: "Rule of XX", value: "--" },
      { label: "Total CV", value: "$250,000.00" },
      { label: "Cash Reserves", value: "$5,000,000.00" },
    ],
  },
  {
    items: [
      { label: "Total Loan Amount", value: "$150,455.00" },
      { label: "Amount Requested", value: "$145,000.00" },
      { label: "Financed Fees", value: "$4,4555.00" },
      { label: "Taxes & Insurance", value: "$1,000.00" },
    ],
  },
  {
    items: [
      { label: "Product", value: "1/1 ARM 2/6 caps" },
      { label: "Final Rate", value: "7.255%" },
      { label: "Principal & Interest", value: "$1,000.00" },
      { label: "Total Monthly Payment", value: "$1,650.00" },
    ],
  },
];

export const BorrowerSummarySection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full items-start gap-4 py-0 mt-[0px] mb-[0px] pt-[24px] pb-[24px]" style={{ paddingLeft: 48, paddingRight: 48 }}>
      <header className="flex items-center w-full">
        <h2 className="font-headline-200 font-[number:var(--headline-200-font-weight)] text-[#273333] text-[length:var(--headline-200-font-size)] tracking-[var(--headline-200-letter-spacing)] leading-[var(--headline-200-line-height)] [font-style:var(--headline-200-font-style)]">
          Summary &amp; Ratios
        </h2>
      </header>
      <div className="flex flex-wrap items-start gap-6 w-full">
        {summaryData.map((column, columnIndex) => (
          <Card
            key={`column-${columnIndex}`}
            className="flex-1 min-w-0 rounded-lg border-0 shadow-none"
          >
            <CardContent className="flex flex-col items-start gap-3 p-2">
              {column.items.map((item, itemIndex) => (
                <div
                  key={`item-${columnIndex}-${itemIndex}`}
                  className="flex items-center justify-between w-full"
                >
                  <span className="font-body-100-16 font-[number:var(--body-100-16-font-weight)] text-[#273333] text-[length:var(--body-100-16-font-size)] tracking-[var(--body-100-16-letter-spacing)] leading-[var(--body-100-16-line-height)] [font-style:var(--body-100-16-font-style)]">
                    {item.label}
                  </span>
                  <span className="font-body-100-16 font-[number:var(--body-100-16-font-weight)] text-[#273333] text-[length:var(--body-100-16-font-size)] tracking-[var(--body-100-16-letter-spacing)] leading-[var(--body-100-16-line-height)] [font-style:var(--body-100-16-font-style)]">
                    {item.value}
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
