import {
  AlertTriangleIcon,
  CalendarIcon,
  LinkIcon,
  ListIcon,
  PercentIcon,
} from "lucide-react";

const navigationItems = [
  {
    icon: PercentIcon,
    label: "Loan Info",
    hasNotification: false,
  },
  {
    icon: LinkIcon,
    label: "Quick Links",
    hasNotification: false,
  },
  {
    icon: ListIcon,
    label: "Checklist",
    hasNotification: false,
  },
  {
    icon: CalendarIcon,
    label: "Key Dates",
    hasNotification: false,
  },
  {
    icon: AlertTriangleIcon,
    label: "Errors",
    hasNotification: true,
  },
];

export const NavigationToolbarSection = (): JSX.Element => {
  return (
    <nav className="mt-auto sticky bottom-0 z-50 flex w-full h-9 items-center justify-center gap-6 bg-white border-t border-[#dee1e1]">
      {navigationItems.map((item, index) => {
        const Icon = item.icon;
        return (
          <button
            key={index}
            className="inline-flex items-center justify-center gap-1 px-4 py-0 h-full hover:bg-gray-50 transition-colors cursor-pointer"
          >
            <Icon className="w-5 h-5 text-[#273333]" />
            <div className="inline-flex items-center gap-0.5">
              <span className="font-caption-100 font-[number:var(--caption-100-font-weight)] text-[#273333] text-[length:var(--caption-100-font-size)] tracking-[var(--caption-100-letter-spacing)] leading-[var(--caption-100-line-height)] whitespace-nowrap [font-style:var(--caption-100-font-style)]">
                {item.label}
              </span>
              {item.hasNotification && (
                <div className="w-1 h-1 bg-[#c63434] rounded-sm" />
              )}
            </div>
          </button>
        );
      })}
    </nav>
  );
};
