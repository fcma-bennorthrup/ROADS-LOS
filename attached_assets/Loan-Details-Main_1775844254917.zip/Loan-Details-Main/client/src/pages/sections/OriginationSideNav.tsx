const sideNavItems = [
  { id: "borrower-information", label: "Borrower Information", enabled: false },
  { id: "loan-details", label: "Loan Details", enabled: false },
  { id: "collateral", label: "Collateral", enabled: false },
  { id: "product-pricing", label: "Product & Pricing", enabled: true },
  { id: "fees", label: "Fees", enabled: false },
];

interface OriginationSideNavProps {
  activeItem?: string;
  onItemSelect?: (id: string) => void;
}

export const OriginationSideNav = ({
  activeItem = "product-pricing",
  onItemSelect,
}: OriginationSideNavProps): JSX.Element => {
  const handleClick = (id: string, enabled: boolean) => {
    if (!enabled) return;
    onItemSelect?.(id);
  };

  return (
    <nav
      className="w-[240px] min-w-[240px] bg-white border-r border-[#dee1e1] flex flex-col self-stretch"
      data-testid="origination-side-nav"
    >
      <div className="flex flex-col gap-2 pt-6 px-4">
        {sideNavItems.map((item) => {
          const isActive = activeItem === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleClick(item.id, item.enabled)}
              disabled={!item.enabled}
              className={`flex items-center gap-3 px-2 py-1 rounded text-left w-full transition-colors ${
                isActive
                  ? "cursor-default"
                  : item.enabled
                    ? "hover:bg-[#f9f9f9] cursor-pointer"
                    : "cursor-default opacity-60"
              }`}
              data-testid={`side-nav-item-${item.id}`}
            >
              <span
                className={`font-['Source_Sans_Pro',sans-serif] text-[16px] leading-[24px] text-[#273333] whitespace-nowrap ${
                  isActive ? "font-semibold" : "font-normal"
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
