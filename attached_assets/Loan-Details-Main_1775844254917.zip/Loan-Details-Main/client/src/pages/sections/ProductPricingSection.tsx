import { useState, useMemo, useRef } from "react";
import { HelpCircleIcon, Pencil, Lock, Calendar, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogClose,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

interface ProductEntry {
  productType: string;
  productId: string;
  label: string;
  term: number;
  baseRate: number;
}

const productData: ProductEntry[] = [
  { productType: "arm", productId: "4251", label: "4251 - 1/1 ARM 2/6 caps", term: 12, baseRate: 6.25 },
  { productType: "arm", productId: "4243", label: "4243 - 3/1 ARM 2/6 caps", term: 36, baseRate: 6.37 },
  { productType: "arm", productId: "4245", label: "4245 - 5/1 ARM 2/6 caps", term: 60, baseRate: 6.5 },
  { productType: "arm", productId: "4247", label: "4247 - 7/1 ARM 2/6 caps", term: 84, baseRate: 6.5 },
  { productType: "arm", productId: "4240", label: "4240 - 10/1 ARM 9/9caps", term: 120, baseRate: 6.5 },
  { productType: "arm", productId: "4242", label: "4242 - 15/1 ARM 9/9 caps", term: 180, baseRate: 6.75 },
  { productType: "fixed", productId: "4370", label: "4370 - 10 year fixed", term: 120, baseRate: 6.125 },
  { productType: "fixed", productId: "4371", label: "4371 - 15 year fixed", term: 180, baseRate: 6.375 },
  { productType: "fixed", productId: "4372", label: "4372 - 20 year fixed", term: 240, baseRate: 6.625 },
  { productType: "fixed", productId: "4373", label: "4373 - 25 year fixed", term: 300, baseRate: 6.75 },
  { productType: "fixed", productId: "4374", label: "4374 - 30 year fixed", term: 360, baseRate: 6.75 },
];

const totalAdjustments = 0.625;
const totalDiscounts = 0.25;

const rateAdjustments = [
  { label: "FICO Score", value: "0.025%" },
  { label: "Loan Size", value: "0.000%" },
  { label: "Property Type", value: "0.625%" },
];

const formatRate = (rate: number): string => rate.toFixed(3) + "%";

const getLockDate = (): string => {
  const date = new Date();
  date.setDate(date.getDate() + 45);
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  const yyyy = date.getFullYear();
  return `${mm}/${dd}/${yyyy}`;
};

export const ProductPricingSection = (): JSX.Element => {
  const [isEditing, setIsEditing] = useState(false);
  const [productType, setProductType] = useState("fixed");
  const [selectedProductId, setSelectedProductId] = useState("4370");
  const [isRateLocked, setIsRateLocked] = useState(false);
  const [isLockModalOpen, setIsLockModalOpen] = useState(false);

  const filteredProducts = useMemo(
    () => productData.filter((p) => p.productType === productType),
    [productType]
  );

  const currentProduct = useMemo(
    () => productData.find((p) => p.productId === selectedProductId) ?? filteredProducts[0],
    [selectedProductId, filteredProducts]
  );

  const baseRate = currentProduct.baseRate;
  const finalRate = baseRate + totalAdjustments - totalDiscounts;

  const handleProductTypeChange = (value: string) => {
    setProductType(value);
    const firstProduct = productData.filter((p) => p.productType === value)[0];
    setSelectedProductId(firstProduct.productId);
  };

  const handleProductChange = (value: string) => {
    setSelectedProductId(value);
  };

  const savedState = useRef({ productType: "fixed", productId: "4370" });

  const handleEditToggle = () => {
    if (!isEditing) {
      savedState.current = { productType, productId: selectedProductId };
    }
    setIsEditing(!isEditing);
  };

  const handleDiscard = () => {
    setProductType(savedState.current.productType);
    setSelectedProductId(savedState.current.productId);
    setIsEditing(false);
  };

  const handleLockRate = () => {
    setIsRateLocked(true);
    setIsLockModalOpen(false);
  };

  return (
    <div className="flex flex-col gap-6 p-6 flex-1 min-w-0 overflow-auto" data-testid="product-pricing-section">
      <h2
        className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[24px] leading-[32px] text-[#273333]"
        data-testid="text-product-pricing-title"
      >
        Product &amp; Pricing
      </h2>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-6 max-w-[1200px]">
          <div
            className="flex items-center border border-[#dee1e1] rounded-lg overflow-hidden"
            data-testid="rate-breakdown-card"
          >
            <div className="flex flex-col items-start justify-center px-4 py-2 border-r border-[#dee1e1] min-w-[180px]">
              <span className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[24px] text-[#273333] whitespace-nowrap">
                Rate Breakdown
              </span>
            </div>
            <div className="flex items-center justify-between px-4 flex-1 min-w-[160px]">
              <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333] whitespace-nowrap">
                Base Rate
              </span>
              <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333] whitespace-nowrap" data-testid="text-base-rate">
                {formatRate(baseRate)}
              </span>
            </div>
            <div className="px-2">
              <span className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[24px] text-[#273333]">
                +
              </span>
            </div>
            <div className="flex items-center justify-between px-4 flex-1 min-w-[160px]">
              <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333] whitespace-nowrap">
                Total Adjustments
              </span>
              <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333] whitespace-nowrap" data-testid="text-total-adjustments">
                {formatRate(totalAdjustments)}
              </span>
            </div>
            <div className="px-2">
              <span className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[24px] text-[#273333]">
                -
              </span>
            </div>
            <div className="flex items-center justify-between px-4 flex-1 min-w-[160px]">
              <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333] whitespace-nowrap">
                Total Discounts
              </span>
              <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333] whitespace-nowrap" data-testid="text-total-discounts">
                {formatRate(totalDiscounts)}
              </span>
            </div>
            <div className="px-2">
              <span className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[24px] text-[#273333]">
                =
              </span>
            </div>
            <div className="flex items-center justify-between px-3 py-2 bg-[#f3f4f4] rounded-br-lg min-w-[180px]">
              <span className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[24px] text-[#273333] whitespace-nowrap">
                Final Rate
              </span>
              <span className="flex items-center gap-1.5 font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[24px] text-[#273333] whitespace-nowrap" data-testid="text-final-rate">
                {formatRate(finalRate)}
                {isRateLocked && <Lock className="w-4 h-4 text-[#273333]" data-testid="icon-rate-locked" />}
              </span>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            {isRateLocked && (
              <Button
                variant="outline"
                className="border-[#929A9B] hover:bg-[#e5eff4] font-['Source_Sans_Pro',sans-serif] font-semibold text-[14px] leading-[20px] h-auto px-3 py-0.5 rounded text-[#273333] !bg-[#FFFFFF]"
                data-testid="button-generate-rate-lock-letter"
              >View Rate Lock Letter</Button>
            )}
            <Button
              onClick={() => setIsLockModalOpen(true)}
              className="bg-[#005B94] hover:bg-[#004a7a] text-white font-['Source_Sans_Pro',sans-serif] font-semibold text-[14px] leading-[20px] h-auto px-2 py-0.5 rounded"
              data-testid="button-lock-rate"
            >
              {isRateLocked ? "Edit Rate Lock" : "Lock Rate"}
            </Button>
          </div>
        </div>

        <div className="flex gap-12 items-start">
          <div className="flex flex-col gap-6 max-w-[1200px] flex-1 min-w-0">
            <div className="flex gap-4 items-start">
              <div className="flex flex-col gap-2 w-[288px]" data-testid="form-field-product-type">
                <label className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[16px] text-[#273333]">
                  Product Type
                </label>
                <Select
                  value={productType}
                  onValueChange={handleProductTypeChange}
                  disabled={!isEditing}
                >
                  <SelectTrigger
                    className="bg-[#f9f9f9] border-[#dee1e1] font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] text-[#273333] h-[44px]"
                    data-testid="select-product-type"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fixed">Fixed</SelectItem>
                    <SelectItem value="arm">ARM</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col gap-2 w-[288px]" data-testid="form-field-product">
                <label className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[16px] text-[#273333]">
                  Product
                </label>
                <Select
                  value={selectedProductId}
                  onValueChange={handleProductChange}
                  disabled={!isEditing}
                >
                  <SelectTrigger
                    className="bg-[#f9f9f9] border-[#dee1e1] font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] text-[#273333] h-[44px]"
                    data-testid="select-product"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredProducts.map((p) => (
                      <SelectItem key={p.productId} value={p.productId}>
                        {p.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col gap-2 w-[288px]" data-testid="form-field-term">
                <label className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[16px] text-[#273333]">
                  Term (Months)
                </label>
                <Input
                  type="text"
                  value={currentProduct.term.toString()}
                  readOnly={!isEditing}
                  disabled={!isEditing}
                  className="bg-[#f9f9f9] border-[#dee1e1] font-['Source_Sans_Pro',sans-serif] font-semibold !text-[16px] text-[#273333] h-[44px]"
                  data-testid="input-term"
                />
              </div>

              <div className="flex flex-col gap-2 w-[288px]" data-testid="form-field-rate">
                <label className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[16px] text-[#273333]">
                  Base Rate
                </label>
                <Input
                  type="text"
                  value={formatRate(baseRate)}
                  readOnly={!isEditing}
                  disabled={!isEditing}
                  className="bg-[#f9f9f9] border-[#dee1e1] font-['Source_Sans_Pro',sans-serif] font-semibold !text-[16px] text-[#273333] h-[44px]"
                  data-testid="input-rate"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 max-w-[1200px]">
              {isEditing ? (
                <>
                  <Button
                    onClick={handleDiscard}
                    className="bg-[#c63434] hover:bg-[#a82b2b] text-white font-['Source_Sans_Pro',sans-serif] font-semibold text-[14px] leading-[20px] h-auto px-2 py-0.5 rounded"
                    data-testid="button-discard-changes"
                  >
                    Discard Changes
                  </Button>
                  <Button
                    onClick={handleEditToggle}
                    className="hover:bg-[#2E79A7] text-white font-['Source_Sans_Pro',sans-serif] font-semibold text-[14px] leading-[20px] h-auto px-2 py-0.5 rounded bg-[#005B94]"
                    data-testid="button-save-changes"
                  >
                    Save Changes
                  </Button>
                </>
              ) : (
                <Button
                  onClick={handleEditToggle}
                  variant="outline"
                  disabled={isRateLocked}
                  className="border-[#929A9B] hover:bg-[#e5eff4] font-['Source_Sans_Pro',sans-serif] font-semibold text-[14px] leading-[20px] h-auto px-3 py-0.5 rounded gap-1.5 text-[#273333] !bg-[#FFFFFF] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-[#FFFFFF]"
                  data-testid="button-edit-product"
                >
                  <Pencil className="w-3 h-3" />
                  Edit
                </Button>
              )}
            </div>
          </div>

          <div className="w-[366px] min-w-[366px]" data-testid="rate-adjustments-panel">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333]">
                Rate Adjustments
              </span>
              <HelpCircleIcon className="w-4 h-4 text-[#273333]" />
            </div>
            <div className="flex flex-col gap-2 bg-[#f9f9f9] rounded p-2">
              {rateAdjustments.map((adj) => (
                <div
                  key={adj.label}
                  className="flex items-center justify-between px-2"
                  data-testid={`rate-adj-${adj.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333]">
                    {adj.label}
                  </span>
                  <span className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[16px] text-[#273333]" data-testid={`text-rate-adj-value-${adj.label.toLowerCase().replace(/\s+/g, '-')}`}>
                    {adj.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <Dialog open={isLockModalOpen} onOpenChange={setIsLockModalOpen}>
        <DialogContent className="p-0 gap-0 max-w-[600px] rounded-lg shadow-[0px_16px_32px_0px_rgba(39,51,51,0.24)] overflow-clip [&>button:last-child]:hidden" data-testid="rate-lock-modal">
          <div className="flex flex-col p-6 border-b border-[#dee1e1]">
            <div className="flex items-start justify-between">
              <DialogTitle className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[24px] leading-[32px] text-[#273333]">
                Rate Lock
              </DialogTitle>
              <DialogClose asChild>
                <button
                  aria-label="Close rate lock modal"
                  className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-[#f3f4f4] transition-colors"
                  data-testid="button-close-lock-modal"
                >
                  <X className="w-4 h-4 text-[#273333]" />
                </button>
              </DialogClose>
            </div>
            <DialogDescription className="font-['Source_Sans_Pro',sans-serif] font-normal text-[16px] leading-[24px] text-[#273333]">
              Please advise borrower of rate lock fees.
            </DialogDescription>
          </div>

          <div className="flex flex-col gap-6 items-center justify-center p-6">
            <div className="flex flex-col gap-2 w-[312px]">
              <label className="font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[16px] text-[#273333]">Rate Lock Expiration Date</label>
              <div className="relative">
                <Input
                  type="text"
                  value={getLockDate()}
                  disabled
                  readOnly
                  className="border-[#929a9b] bg-white font-['Source_Sans_Pro',sans-serif] font-semibold !text-[16px] text-[#273333] h-[44px] pr-10 disabled:opacity-100 disabled:cursor-default"
                  data-testid="input-lock-date"
                />
                <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#273333] pointer-events-none" />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between p-6 border-t border-[#dee1e1]">
            <p className="font-['Source_Sans_Pro',sans-serif] font-normal text-[14px] leading-[20px] text-[#273333]">
              Initial Rate Lock Period is 45 days.
            </p>
            <div className="flex items-center gap-4">
              <DialogClose asChild>
                <button
                  className="px-4 py-2 font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[16px] text-[#273333] hover:bg-[#f3f4f4] rounded transition-colors"
                  data-testid="button-cancel-lock"
                >
                  Cancel
                </button>
              </DialogClose>
              <Button
                onClick={handleLockRate}
                className="bg-[#005B94] hover:bg-[#2E79A7] text-white font-['Source_Sans_Pro',sans-serif] font-semibold text-[16px] leading-[16px] h-auto px-4 py-2 rounded"
                data-testid="button-confirm-lock-rate"
              >
                Lock Rate
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
