import {
  CheckIcon,
  ChevronRightIcon,
  MenuIcon,
  MessageCircleIcon,
  MoreVerticalIcon,
} from "lucide-react";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

const breadcrumbItems = [
  { label: "Pipeline", href: "#" },
  { label: "Loan: 123456789", href: "#" },
  { label: "Level Three", href: "#" },
];

const loanStages = [
  { label: "Customer Application", active: false, completed: true },
  { label: "Pre-Approval", active: false, completed: true },
  { label: "Loan Setup", active: true, completed: false },
  { label: "Decisioning", active: false, completed: false },
  { label: "Loan Finalization", active: false, completed: false },
  { label: "Closing", active: false, completed: false },
  { label: "Booking", active: false, completed: false },
  { label: "Loan Certification", active: false, completed: false },
];

const loanTeamAvatars = [
  { src: "/figmaAssets/avatar-2.png", alt: "Team member 1" },
  { src: "/figmaAssets/avatar-1.png", alt: "Team member 2" },
  { src: "/figmaAssets/avatar.png", alt: "Team member 3" },
];

const metadataItems = [
  { label: "Construction" },
  { label: "Loan: 123456789" },
  { label: "CIF: 1234567" },
];

const navigationTabs = [
  { value: "summary", label: "Summary" },
  { value: "origination", label: "Origination" },
  { value: "decisioning", label: "Decisioning" },
  { value: "closing-booking", label: "Closing & Booking" },
  { value: "documents", label: "Documents" },
  { value: "history", label: "History" },
];

interface LoanHeaderSectionProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export const LoanHeaderSection = ({
  activeTab = "origination",
  onTabChange,
}: LoanHeaderSectionProps): JSX.Element => {
  return (
    <header className="flex flex-col items-start gap-4 pt-4 pb-0 px-6 relative w-full bg-white border-b border-[#dee1e1]">
      <div className="flex flex-col items-start gap-4 relative self-stretch w-full">
        <div className="flex items-center justify-between relative self-stretch w-full">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-auto w-auto p-0"
                  data-testid="button-menu"
                >
                  <MenuIcon className="w-5 h-5" />
                </Button>
              </BreadcrumbItem>
              {breadcrumbItems.map((item, index) => (
                <div key={index} className="inline-flex items-center gap-1">
                  {index > 0 && (
                    <BreadcrumbSeparator>
                      <ChevronRightIcon className="w-5 h-5" />
                    </BreadcrumbSeparator>
                  )}
                  <BreadcrumbItem>
                    <BreadcrumbLink
                      href={item.href}
                      className="font-body-100-16 font-[number:var(--body-100-16-font-weight)] text-[#273333] text-[length:var(--body-100-16-font-size)] tracking-[var(--body-100-16-letter-spacing)] leading-[var(--body-100-16-line-height)] [font-style:var(--body-100-16-font-style)]"
                    >
                      {item.label}
                    </BreadcrumbLink>
                  </BreadcrumbItem>
                </div>
              ))}
            </BreadcrumbList>
          </Breadcrumb>

          <div className="inline-flex items-center gap-4">
            <div className="inline-flex items-center gap-2">
              <span className="font-caption-100-strong font-[number:var(--caption-100-strong-font-weight)] text-[#273333] text-[length:var(--caption-100-strong-font-size)] tracking-[var(--caption-100-strong-letter-spacing)] leading-[var(--caption-100-strong-line-height)] [font-style:var(--caption-100-strong-font-style)]">
                Viewing
              </span>
              <Avatar className="w-5 h-5 bg-[#dee1e1]">
                <AvatarFallback className="font-caption-100 font-[number:var(--caption-100-font-weight)] text-[#273333] text-[length:var(--caption-100-font-size)] tracking-[var(--caption-100-letter-spacing)] leading-[var(--caption-100-line-height)] [font-style:var(--caption-100-font-style)]">
                  RD
                </AvatarFallback>
              </Avatar>
            </div>

            <div className="inline-flex items-center gap-2">
              <span className="font-caption-100-strong font-[number:var(--caption-100-strong-font-weight)] text-[#273333] text-[length:var(--caption-100-strong-font-size)] tracking-[var(--caption-100-strong-letter-spacing)] leading-[var(--caption-100-strong-line-height)] [font-style:var(--caption-100-strong-font-style)]">
                Loan Team
              </span>
              <div className="relative w-[62px] h-5">
                <div className="inline-flex flex-col items-start gap-2.5 px-[5px] py-0 absolute top-[calc(50.00%_-_8px)] left-10 rounded-full">
                  <span className="font-caption-100 font-[number:var(--caption-100-font-weight)] text-[#005b94] text-[length:var(--caption-100-font-size)] tracking-[var(--caption-100-letter-spacing)] leading-[var(--caption-100-line-height)] [font-style:var(--caption-100-font-style)]">
                    +3
                  </span>
                </div>
                {loanTeamAvatars.map((avatar, index) => (
                  <Avatar
                    key={index}
                    className="absolute top-[calc(50.00%_-_11px)] w-[22px] h-[22px] border border-white"
                    style={{ left: `${index * 10 - 1}px` }}
                  >
                    <AvatarImage src={avatar.src} alt={avatar.alt} />
                  </Avatar>
                ))}
              </div>
            </div>

            <div className="inline-flex items-center gap-2">
              <Button variant="ghost" size="icon" className="h-auto w-auto p-0" data-testid="button-message">
                <MessageCircleIcon className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="h-auto w-auto p-0" data-testid="button-sidebar">
                <img
                  className="w-5 h-5"
                  alt="Sidebar"
                  src="/figmaAssets/sidebar-1.svg"
                />
              </Button>
              <Button variant="ghost" size="icon" className="h-auto w-auto p-0" data-testid="button-more-options">
                <MoreVerticalIcon className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex items-center self-stretch w-full relative">
          {loanStages.map((stage, index) => {
            const bgColor = stage.active
              ? "#005b94"
              : stage.completed
                ? "#e5eff4"
                : "#dee1e1";
            const textColor = stage.active
              ? "text-white"
              : stage.completed
                ? "text-[#005b94]"
                : "text-[#515e5f]";
            const isFirst = index === 0;
            const isLast = index === loanStages.length - 1;
            const arrowWidth = 10;

            const clipPath = `polygon(0 0, calc(100% - ${arrowWidth}px) 0, 100% 50%, calc(100% - ${arrowWidth}px) 100%, 0 100%, ${arrowWidth}px 50%)`;

            return (
              <div
                key={index}
                className="flex-1 relative h-7 flex items-center"
                style={{
                  marginLeft: isFirst ? 0 : -(arrowWidth - 2),
                  zIndex: loanStages.length - index,
                  clipPath,
                  backgroundColor: bgColor,
                }}
                data-testid={`stepper-stage-${index}`}
              >
                <div
                  className="flex items-center justify-center gap-1 w-full"
                  style={{
                    paddingLeft: arrowWidth + 4,
                    paddingRight: arrowWidth + 4,
                  }}
                >
                  {stage.completed && (
                    <CheckIcon
                      className="w-3.5 h-3.5 text-[#005b94] flex-shrink-0"
                      strokeWidth={2.5}
                    />
                  )}
                  <span
                    className={`font-caption-100-strong font-[number:var(--caption-100-strong-font-weight)] ${textColor} text-[length:var(--caption-100-strong-font-size)] text-center tracking-[var(--caption-100-strong-letter-spacing)] leading-[var(--caption-100-strong-line-height)] whitespace-nowrap [font-style:var(--caption-100-strong-font-style)]`}
                  >
                    {stage.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex flex-col items-start gap-0.5 relative self-stretch w-full">
        <div className="inline-flex items-center gap-1">
          {metadataItems.map((item, index) => (
            <div key={index} className="inline-flex items-center gap-1">
              {index > 0 && (
                <Separator
                  orientation="vertical"
                  className="h-4 w-px bg-[#dee1e1]"
                />
              )}
              <span className="font-caption-100 font-[number:var(--caption-100-font-weight)] text-[#273333] text-[length:var(--caption-100-font-size)] tracking-[var(--caption-100-letter-spacing)] leading-[var(--caption-100-line-height)] [font-style:var(--caption-100-font-style)]">
                {item.label}
              </span>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-4 relative self-stretch w-full">
          <h1 className="font-headline-100 font-[number:var(--headline-100-font-weight)] text-[#273333] text-[length:var(--headline-100-font-size)] tracking-[var(--headline-100-letter-spacing)] leading-[var(--headline-100-line-height)] [font-style:var(--headline-100-font-style)]">
            Richard Jamerson
          </h1>
        </div>

        <div className="inline-flex items-center justify-center gap-2">
          <span className="font-headline-300 font-[number:var(--headline-300-font-weight)] text-[#273333] text-[length:var(--headline-300-font-size)] tracking-[var(--headline-300-letter-spacing)] leading-[var(--headline-300-line-height)] [font-style:var(--headline-300-font-style)]">
            $150,000.00
          </span>

          <Badge
            variant="secondary"
            className="bg-[#e5eff4] text-[#005b94] hover:bg-[#e5eff4] font-body-200-strong font-[number:var(--body-200-strong-font-weight)] text-[length:var(--body-200-strong-font-size)] tracking-[var(--body-200-strong-letter-spacing)] leading-[var(--body-200-strong-line-height)] [font-style:var(--body-200-strong-font-style)]"
          >
            Joint Credit Application
          </Badge>

          <Separator orientation="vertical" className="h-4 w-px bg-[#dee1e1]" />

          <Badge
            variant="secondary"
            className="bg-[#fdefcd] text-[#dd9903] hover:bg-[#fdefcd] font-body-200-strong font-[number:var(--body-200-strong-font-weight)] text-[length:var(--body-200-strong-font-size)] tracking-[var(--body-200-strong-letter-spacing)] leading-[var(--body-200-strong-line-height)] [font-style:var(--body-200-strong-font-style)]"
          >
            14 ECOA Days Remaining
          </Badge>

          <Badge
            variant="secondary"
            className="bg-[#ffd5d2] text-[#c63434] hover:bg-[#ffd5d2] font-body-200-strong font-[number:var(--body-200-strong-font-weight)] text-[length:var(--body-200-strong-font-size)] tracking-[var(--body-200-strong-letter-spacing)] leading-[var(--body-200-strong-line-height)] [font-style:var(--body-200-strong-font-style)]"
          >
            3 TRID Days Remaining
          </Badge>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
        <TabsList className="inline-flex items-start h-auto bg-transparent p-0 rounded-none">
          {navigationTabs.map((tab) => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="px-6 py-4 rounded-none border-b-2 border-transparent data-[state=active]:border-[#005b94] data-[state=active]:bg-transparent bg-transparent data-[state=active]:shadow-none font-ui-specific-label-strong font-[number:var(--ui-specific-label-strong-font-weight)] text-[length:var(--ui-specific-label-strong-font-size)] tracking-[var(--ui-specific-label-strong-letter-spacing)] leading-[var(--ui-specific-label-strong-line-height)] [font-style:var(--ui-specific-label-strong-font-style)] data-[state=active]:text-[#005b94] text-[#273333]"
              data-testid={`tab-${tab.value}`}
            >
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>
    </header>
  );
};
