import { useState } from "react";
import { BorrowerSummarySection } from "./sections/BorrowerSummarySection";
import { LoanDetailsSection } from "./sections/LoanDetailsSection";
import { LoanHeaderSection } from "./sections/LoanHeaderSection";
import { NavigationToolbarSection } from "./sections/NavigationToolbarSection";
import { OriginationSideNav } from "./sections/OriginationSideNav";
import { ProductPricingSection } from "./sections/ProductPricingSection";

export const SummaryPage = (): JSX.Element => {
  const [activeTab, setActiveTab] = useState("origination");

  return (
    <div className="flex flex-col w-full min-h-screen bg-white">
      <LoanHeaderSection activeTab={activeTab} onTabChange={setActiveTab} />

      {activeTab === "summary" && (
        <div className="flex-1">
          <LoanDetailsSection />
          <BorrowerSummarySection />
        </div>
      )}

      {activeTab === "origination" && (
        <div className="flex flex-1 items-stretch overflow-hidden">
          <OriginationSideNav />
          <ProductPricingSection />
        </div>
      )}

      {activeTab !== "summary" && activeTab !== "origination" && (
        <div className="flex-1 flex items-center justify-center">
          <p className="font-['Source_Sans_Pro',sans-serif] text-[16px] text-[#515e5f]">
            Content for this tab is coming soon.
          </p>
        </div>
      )}

      <NavigationToolbarSection />
    </div>
  );
};
